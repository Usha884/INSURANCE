# insurancemanagement
This project uses MySQL and PHP. This project mainly focuses on effective use of database and data in it, i.e. database management.  
In this project, a person can enter the client details as well as their policy data. The user can view, edit, and delete the data in the database using the web page.

This project also contains the report about the whole project idea and the management in this. 

Pre procedure to follow:
1. Import the database in the localhost/phpmyadmin
2. Then start from from the index.php file which is the home page
